# Diccionario con los archivos a procesar:

archivos = {1: {'file_name': 'users', 'file_path': 'C:/Users/Pacarena/Documents/GELT_data/users.csv'}, 
2: {'file_name': 'tickets', 'file_path':'C:/Users/Pacarena/Documents/GELT_data/tickets.csv'}, 
3: {'file_name': 'ticket_lines', 'file_path': 'C:/Users/Pacarena/Documents/GELT_data/ticket_lines.csv'}}

# Diccionario con los datos del servidor y la base de datos del SQL Server:

server_data = {'server': 'CUCALAGRANDE\SQLEXPRESS', 'database':'Gelt'}




